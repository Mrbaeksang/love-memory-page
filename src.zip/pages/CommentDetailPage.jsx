import React, { useEffect, useState, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabaseClient";
import styles from "./CommentDetailPage.module.css";

const CommentDetailPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const modalImgRef = useRef(null);
  const [comments, setComments] = useState([]);
  const params = new URLSearchParams(location.search);
  const imgUrl = params.get("img");

  useEffect(() => {
    const fetchComments = async () => {
      const { data } = await supabase
        .from("gallery_comments")
        .select("*")
        .eq("image_url", imgUrl)
        .order("created_at", { ascending: false });
      setComments(data || []);
    };
    if (imgUrl) fetchComments();
  }, [imgUrl]);

  return (
    <div className={styles["comment-detail-container"]}>
      <button onClick={() => navigate(-1)} className={styles["comment-detail-back"]}>
        ← 뒤로가기
      </button>

      {imgUrl && (
        <div className={styles["comment-detail-image-wrapper"]}>
          <img
            ref={modalImgRef}
            src={imgUrl}
            alt="상세 이미지"
            className={styles["comment-detail-image"]}
          />
        </div>
      )}

      <div className={styles["comment-detail-box"]}>
        <h3 className={styles["comment-detail-title"]}>💬 댓글</h3>
        {comments.length === 0 ? (
          <p className={styles["comment-detail-empty"]}>아직 댓글이 없습니다.</p>
        ) : (
          comments.map((c) => (
            <div key={c.id} className={styles["comment-detail-item"]}>
              <p>{c.content}</p>
              <span className={styles["comment-detail-date"]}>
                {new Date(c.created_at).toLocaleDateString()}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default CommentDetailPage;
