import React, {
  useEffect,
  useState,
  useRef,
  useCallback,
} from "react";
import { supabase } from "../lib/supabaseClient";
import { useNavigate } from "react-router-dom";
import "./TravelMap.css";
import { sendPushToAll } from "../utils/sendPushToAll";
import { getAnonId } from "../utils/getAnonId";
import MarkerImageModal from "../components/MarkerImageModal";
import MarkerImageUploadModal from "../components/MarkerImageUploadModal";

const naverClientId = import.meta.env.VITE_NAVER_CLIENT_ID;

export default function TravelMap() {
  const navigate = useNavigate();
  const mapRef = useRef(null);
  const [naverMap, setNaverMap] = useState(null);
  const [markers, setMarkers] = useState([]);
  const [newMarker, setNewMarker] = useState(null);
  const [form, setForm] = useState({ region: "", reason: "", type: "want" });
  const [selectedMarker, setSelectedMarker] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [showImageModal, setShowImageModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [mapLoading, setMapLoading] = useState(true);
  const [mapError, setMapError] = useState(null);

  // 네이버 지도 API 로드 및 초기화
  useEffect(() => {
    const script = document.createElement("script");
    script.id = "naver-maps-script";
    script.src = `https://openapi.map.naver.com/openapi/v3/maps.js?ncpClientId=${naverClientId}&submodules=geocoder`;
    script.async = true;

    script.onload = () => {
      setMapLoading(false);
      initializeMap();
    };

    script.onerror = () => {
      setMapError("Failed to load Naver Maps.");
      setMapLoading(false);
    };

    document.head.appendChild(script);

    return () => {
      const mapScript = document.getElementById("naver-maps-script");
      if (mapScript) {
        mapScript.remove();
      }
    };
  }, []);

  const initializeMap = () => {
    try {
      if (mapRef.current) {
        const mapOptions = {
          center: new window.naver.maps.LatLng(36.5, 127.5),
          zoom: 7,
        };
        const map = new window.naver.maps.Map(mapRef.current, mapOptions);
        setNaverMap(map);

        // 지도 클릭 이벤트 처리
        window.naver.maps.Event.addListener(map, "click", (e) => {
          setNewMarker({
            lat: e.coord.lat(),
            lng: e.coord.lng(),
          });
        });
      } else {
        console.error("Map container element not found.");
        setMapError("Could not find map container.");
      }
    } catch (error) {
      console.error("Map initialization error:", error);
      setMapError("Could not initialize the map.");
    }
  };

  // 주소 검색 기능
  const searchAddress = useCallback(
    async (query) => {
      if (!query.trim()) return;

      try {
        window.naver.maps.Service.geocode(
          {
            query,
          },
          (status, response) => {
            if (status === window.naver.maps.Service.Status.ERROR) {
              console.error("주소 검색 에러");
              return alert("주소 검색에 실패했습니다.");
            }

            if (response.v2.meta.totalCount === 0) {
              return alert("검색 결과가 없습니다.");
            }

            const item = response.v2.addresses[0];
            const point = new window.naver.maps.Point(item.x, item.y);
            naverMap.setCenter(point);
            setNewMarker({ lat: item.y, lng: item.x }); // 검색 결과 위치에 마커 추가
          }
        );
      } catch (error) {
        console.error("주소 검색 실패:", error);
        alert("주소 검색 중 오류가 발생했습니다.");
      }
    },
    [naverMap]
  );

  // 마커 저장
  const saveMarker = async () => {
    if (!form.region.trim() || !form.reason.trim() || !newMarker) {
      alert("Please fill in all fields.");
      return;
    }

    try {
      const { lat, lng } = newMarker;
      const { data, error } = await supabase
        .from("travel_markers")
        .insert({ ...form, lat, lng })
        .select();

      if (error || !data?.[0]) throw error;

      const newId = data[0].id;
      await sendPushToAll({
        title: `${form.region} added!`,
        body: form.reason,
        click_action: `/#/travel?marker=${newId}`,
        excludeUserId: getAnonId(),
      });

      setMarkers([...markers, data[0]]);
      setNewMarker(null);
      setForm({ region: "", reason: "", type: "want" });
      alert("Marker saved!");
    } catch (error) {
      console.error("Error saving marker:", error);
      alert("Could not save marker.");
    }
  };

  // UI 렌더링
  if (mapLoading) return <div>Loading Map...</div>;
  if (mapError) return <div>{mapError}</div>;

  return (
    <div className="travel-map-container">
      <div id="map" ref={mapRef} style={{ width: "100%", height: "500px" }}></div>

      <div className="search-container">
        <input
          type="text"
          placeholder="Search places"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              searchAddress(searchQuery);
            }
          }}
        />
        <button onClick={() => searchAddress(searchQuery)}>Search</button>
      </div>

      {newMarker && (
        <div className="marker-form">
          <div className="marker-type-selector">
            <button
              onClick={() => setForm({ ...form, type: "want" })}
              className={form.type === "want" ? "active" : ""}
            >
              Want to Visit
            </button>
            <button
              onClick={() => setForm({ ...form, type: "visited" })}
              className={form.type === "visited" ? "active" : ""}
            >
              Visited
            </button>
          </div>

          <input
            placeholder="Location Name"
            value={form.region}
            onChange={(e) => setForm({ ...form, region: e.target.value })}
          />
          <textarea
            placeholder="Reason"
            value={form.reason}
            onChange={(e) => setForm({ ...form, reason: e.target.value })}
          />

          <div className="form-buttons">
            <button onClick={() => setNewMarker(null)}>Cancel</button>
            <button onClick={saveMarker}>Save Marker</button>
          </div>
        </div>
      )}

      {selectedMarker && (
        <div className="comment-modal">
          <div className="modal-content">
            <h2>{selectedMarker.region}</h2>
            <p>{selectedMarker.reason}</p>

            <div className="comment-list">
              {comments.map((comment, index) => (
                <div key={index} className="comment">
                  <p>{comment.content}</p>
                  <small>
                    {new Date(comment.created_at).toLocaleString()}
                  </small>
                </div>
              ))}
            </div>

            <div className="comment-input">
              <input
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    submitComment();
                  }
                }}
              />
              <button onClick={submitComment}>Submit</button>
            </div>

            <button onClick={() => setSelectedMarker(null)}>Close</button>
          </div>
        </div>
      )}

      {showImageModal && selectedMarker && (
        <MarkerImageModal
          markerId={selectedMarker.id}
          onClose={() => setShowImageModal(false)}
        />
      )}

      {showUploadModal && selectedMarker && (
        <MarkerImageUploadModal
          markerId={selectedMarker.id}
          onClose={() => setShowUploadModal(false)}
          onUploadSuccess={() => {
            setShowUploadModal(false);
            setShowImageModal(true);
          }}
        />
      )}
    </div>
  );
}