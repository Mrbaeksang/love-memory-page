// src/components/RandomCommentedImageButton.jsx

import React, { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import "./RandomCommentedImageButton.css"; // 버튼 스타일이 있다면

const RandomCommentedImageButton = ({ onSelect }) => {
  const [loading, setLoading] = useState(false);

  const handleClick = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from("gallery_comments")
      .select("image_url")
      .neq("image_url", "")
      .order("created_at", { ascending: false });

    setLoading(false);

    if (error || !data?.length) {
      alert("댓글이 달린 이미지가 없습니다.");
      return;
    }

    const urls = [...new Set(data.map((d) => d.image_url))];
    const random = urls[Math.floor(Math.random() * urls.length)];

    if (random) onSelect(random);
  };

  return (
    <div style={{ textAlign: "center", margin: "1.5rem 0" }}>
      <button
        onClick={handleClick}
        className="gallery-random-comment-btn"
        disabled={loading}
      >
        {loading ? "불러오는 중..." : "💬 댓글 달린 사진 보기"}
      </button>
    </div>
  );
};

export default RandomCommentedImageButton;
